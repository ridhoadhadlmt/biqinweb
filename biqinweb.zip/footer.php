<footer class="footer">
	<!-- <div class="social-media">
  		<div class="fb">
  			<a href="" class="">
  				<div class="icon">
  					<i class="icofont-facebook"></i>
  				</div>
  			</a>
  		</div>
  		<div class="ig">
  			<a href="" class="">
  				<div class="icon">
  					<i class="icofont-instagram"></i>
  				</div>
  			</a>
  		</div>
  		<div class="wa">
  			<a href="" class="">
  				<div class="icon">
  					<i class="icofont-whatsapp"></i>
  				</div>
  			</a>
  		</div>
  		<div class="tw">
  			<a href="" class="">
  				<div class="icon">
  					<i class="icofont-twitter"></i>
  				</div>
  			</a>
  		</div>
  	</div> -->
  	<div class="license">
     <p>Copyright | 2020 by biQinweb.com</p> 
    </div>
  	<div class="gototop-area">
  	 <button class="btn gototop"><i class="icofont-arrow-up"></i></button>
  	</div>
</footer>


<script type="text/javascript" src="js/jquery-3.4.1.min.js"></script>
<script type="text/javascript" src="js/bootstrap.min.js"></script>
<script type="text/javascript" src="js/owl.carousel.min.js"></script>
<script type="text/javascript" src="js/particles.min.js"></script>
<script type="text/javascript" src="js/app.js"></script>
<script type="text/javascript" src="js/aos.js"></script>
<script type="text/javascript" src="js/main.js"></script>

<script type="text/javascript">
  (function () {
    Var options = {
        Whatsapp: “082272549103”,
        Call_to_action: “Kirimkan pesan anda”, 
        Position: “right”,
    };
    Var proto = document.location.protocol, host = “getbutton.io”, url = proto + “//static.” + host;
    Var s = document.createElement(‘script’); s.type = ‘text/javascript’; s.async = true; s.src = url + ‘/widget-send-button/js/init.js’;
    s.onload = function () { WhWidgetSendButton.init(host, proto, options); };
    var x = document.getElementsByTagName(‘script’)[0]; x.parentNode.insertBefore(s, x);
 })();   
</script>
</body>
</html>